var a00097 =
[
    [ "syntax_error", "a00097.html#afae8be4ad0815338687d765729f09fd4", null ],
    [ "syntax_error", "a00097.html#ac6344fdccdc0e166ff7fcbe53bcc27ef", null ],
    [ "error_position", "a00097.html#ae489a0cf604c668f9dbaa89a3df9dedd", null ]
];