var a00087 =
[
    [ "difference_type", "a00087.html#af9cfc40abd39a68880b0df6d618e41fb", null ],
    [ "size_type", "a00087.html#a85ee6b4652b659565fede97bb00b4232", null ],
    [ "stateless_cursor", "a00087.html#aa042b1c72b16911a4f2e1c73be3d8942", null ],
    [ "stateless_cursor", "a00087.html#a8231490bf29aa7686c4daa3b1fc97ed1", null ],
    [ "close", "a00087.html#a20a0b658655a3b10543abd35717dd633", null ],
    [ "name", "a00087.html#a9b99a8f9ef260f11a32b29e917bdacda", null ],
    [ "retrieve", "a00087.html#a97046479f709ae621473c48ed7a0932d", null ],
    [ "size", "a00087.html#ae278f24bab98d3946061934a48992067", null ]
];