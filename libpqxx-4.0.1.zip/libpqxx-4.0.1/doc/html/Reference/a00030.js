var a00030 =
[
    [ "difference_type", "a00030.html#a746c725327e1dfd598708bfeb8834992", null ],
    [ "size_type", "a00030.html#a732bb16c01dc3266d424267252d4f1b0", null ],
    [ "accesspolicy", "a00030.html#a591ac7d2302288890c04e6159eb6d30e", [
      [ "forward_only", "a00030.html#a591ac7d2302288890c04e6159eb6d30eaf440221f717464c87f043899cc117cbf", null ],
      [ "random_access", "a00030.html#a591ac7d2302288890c04e6159eb6d30ea7f6c1ed7719885433353a78946b2c5f3", null ]
    ] ],
    [ "ownershippolicy", "a00030.html#a8d5f8214ede2ab27dd588defc2847330", [
      [ "owned", "a00030.html#a8d5f8214ede2ab27dd588defc2847330a3ace6a7a5ca4ec3b486f2f35fd2420b0", null ],
      [ "loose", "a00030.html#a8d5f8214ede2ab27dd588defc2847330a4c37408c49492bfe9f012812226dd1fd", null ]
    ] ],
    [ "updatepolicy", "a00030.html#aba6fa56f1ef2d25c3c73240de6b9c212", [
      [ "read_only", "a00030.html#aba6fa56f1ef2d25c3c73240de6b9c212a8122c0c4a5eb9c9dbf27ab40a2686eb0", null ],
      [ "update", "a00030.html#aba6fa56f1ef2d25c3c73240de6b9c212a12fa229ee3e760f1ca86d66304554b63", null ]
    ] ],
    [ "cursor_base", "a00030.html#a92ebe0bfff015fc1d85ab30d1ac97ef4", null ],
    [ "all", "a00030.html#a56b530ba6b18f3fcdb5b93a0087922c9", null ],
    [ "backward_all", "a00030.html#ae1e1a28e596a78fa8ed8c4eeccbe6369", null ],
    [ "name", "a00030.html#ab46d430e0ecfa545ff3764f867654caf", null ],
    [ "next", "a00030.html#a2a10af042c1ece1f5faf55479ada0319", null ],
    [ "prior", "a00030.html#aed642c9d80cddf181853d36c6e8ccb93", null ],
    [ "m_name", "a00030.html#a947b286d508fad4a1823f8b13a5ccef3", null ]
];