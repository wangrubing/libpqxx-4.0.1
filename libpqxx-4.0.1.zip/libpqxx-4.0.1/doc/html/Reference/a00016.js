var a00016 =
[
    [ "char_type", "a00016.html#a1a64cbf69fea84c3ac667ff3b82f0f5b", null ],
    [ "int_type", "a00016.html#a905e17859fef67e93d7baeef86dee98b", null ],
    [ "off_type", "a00016.html#a85661c90be7df5a4f32cb40fa63c4311", null ],
    [ "pos_type", "a00016.html#ab17e48ba1fdbf06183149442e78cb1d0", null ],
    [ "eof", "a00016.html#af4835e096d911543121767d0402e212a", null ]
];