var a00083 =
[
    [ "isolation_tag", "a00083.html#a8fb228809bd42b2936ada9f9573d30d6", null ],
    [ "robusttransaction", "a00083.html#ae28452f4e178b6c548f6294fee803632", null ],
    [ "~robusttransaction", "a00083.html#af1b175fd37479937c936f172803f40bb", null ]
];