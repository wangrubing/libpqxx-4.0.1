var a00058 =
[
    [ "off_type", "a00058.html#acb1cfe19cef8d7b46ecddaa5f2231e9a", null ],
    [ "openmode", "a00058.html#a56b79eb0d4019b7bfd63a914a530f2ca", null ],
    [ "pos_type", "a00058.html#aea8ca1d1275b9a68f8b991ef253e9067", null ],
    [ "seekdir", "a00058.html#adaa7a89a1902ba3f13be9c7ed6c1fa0b", null ],
    [ "size_type", "a00058.html#a546f724f294272c84c85ab4b4b415419", null ],
    [ "largeobjectaccess", "a00058.html#a6a83ff716d73bdf627d8ad29405b297d", null ],
    [ "largeobjectaccess", "a00058.html#af58cb0a2bfe6da7b3d17a572fd4ae573", null ],
    [ "largeobjectaccess", "a00058.html#abe93b38428b31cc1a533381f055fb3b8", null ],
    [ "largeobjectaccess", "a00058.html#aa93b5a0de67a09ab92514670ebcca638", null ],
    [ "~largeobjectaccess", "a00058.html#ac984b12f6980c477bfd3d895576635a6", null ],
    [ "cread", "a00058.html#a2552356fe475dc48fb5f3badb39cccc6", null ],
    [ "cseek", "a00058.html#afa13d389b11eac8063ade1febb7a4e2c", null ],
    [ "ctell", "a00058.html#aef7bc42d2a46bbb09c19c802616fa559", null ],
    [ "cwrite", "a00058.html#a0e047fa337f4df3838e983ca922fa7a5", null ],
    [ "process_notice", "a00058.html#afb99c68925c9dad182c41036ead832ae", null ],
    [ "read", "a00058.html#aac375f66e0a9fb817e4e59a1e73f6ba7", null ],
    [ "seek", "a00058.html#ae74922e23584d6410cf37f89f10c1a53", null ],
    [ "tell", "a00058.html#af81ac99156f3a319e8c021ac2e12da42", null ],
    [ "to_file", "a00058.html#a4adb675b5aed487e66d986fde3d54b4c", null ],
    [ "write", "a00058.html#ad04b47cf5b016f02e855f5e9c0bbccae", null ],
    [ "write", "a00058.html#aaaad87ca613bccb90e5a8c61a45d83ef", null ]
];