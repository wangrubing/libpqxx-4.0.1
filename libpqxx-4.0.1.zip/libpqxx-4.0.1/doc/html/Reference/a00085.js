var a00085 =
[
    [ "sql_cursor", "a00085.html#a78ee80852828a1221357352ce77b9597", null ],
    [ "sql_cursor", "a00085.html#a4e8540e040830b7834749c51d1eb39c0", null ],
    [ "~sql_cursor", "a00085.html#a5957a76f8d79ad8eae5feee9722eff40", null ],
    [ "close", "a00085.html#a866cc9ec5bc766135e80a38901833e37", null ],
    [ "empty_result", "a00085.html#af02410eca37436cb84547357d0b5a38e", null ],
    [ "endpos", "a00085.html#a3ae9feae24d5eab6cf30867351cee54e", null ],
    [ "fetch", "a00085.html#ac356fb51140719a5703d8c5c6784ebb5", null ],
    [ "fetch", "a00085.html#a7c17e5396e312c2f3e0f66db3d0e4a90", null ],
    [ "move", "a00085.html#a2aefb76b1cea234cc687735a3f8bc51a", null ],
    [ "move", "a00085.html#a31a9e2e6f5276c06120111df47f9ac5f", null ],
    [ "pos", "a00085.html#a5a8ff4f51d2a249f1e772e0953452684", null ]
];