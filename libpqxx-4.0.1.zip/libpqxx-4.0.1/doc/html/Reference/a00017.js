var a00017 =
[
    [ "char_type", "a00017.html#a36f5165a10ea513315f12ed9f31c573b", null ],
    [ "int_type", "a00017.html#ae800195a00697cc19af347efb85911ae", null ],
    [ "off_type", "a00017.html#a8f7c4801c946a458c3b909375e934e76", null ],
    [ "pos_type", "a00017.html#a4878de00d941c62fc466ef18b8327e95", null ],
    [ "eof", "a00017.html#aef731d39bc5048c2a417b6822fd125f6", null ]
];