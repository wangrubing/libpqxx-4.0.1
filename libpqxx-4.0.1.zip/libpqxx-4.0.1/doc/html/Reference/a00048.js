var a00048 =
[
    [ "integrity_constraint_violation", "a00048.html#a9fa871a08c23b2722a42fa545cecd2ab", null ],
    [ "integrity_constraint_violation", "a00048.html#a505ae8d71add1a4c19e69f5cf96cea9d", null ]
];