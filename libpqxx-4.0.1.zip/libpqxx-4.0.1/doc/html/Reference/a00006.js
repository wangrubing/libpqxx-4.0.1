var a00006 =
[
    [ "basic_connection", "a00006.html#aa02e7329e13fdc9809c1215f224ab5fe", null ],
    [ "basic_connection", "a00006.html#a0436a1271586987e97bdf5b59b96f607", null ],
    [ "basic_connection", "a00006.html#aa6c74a9abcfa2b13c2334d0c38f66305", null ],
    [ "~basic_connection", "a00006.html#a3abaa953e318c2dda1b61b3f5861140e", null ],
    [ "options", "a00006.html#af041bd491664d3d3c81e7ad9e701d593", null ]
];