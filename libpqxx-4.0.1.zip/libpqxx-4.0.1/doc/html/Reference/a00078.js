var a00078 =
[
    [ "reactivation_avoidance_counter", "a00078.html#a87bd978d6269ea43fdcdf2f2eb278ef5", null ],
    [ "add", "a00078.html#a4f2bdaaec1119d4a66efe42faa17a0dd", null ],
    [ "clear", "a00078.html#a1560ca3d205af226866a1e388dc505f2", null ],
    [ "get", "a00078.html#a1cc2be7fd873ff9c6fa91e3efb3293dd", null ]
];