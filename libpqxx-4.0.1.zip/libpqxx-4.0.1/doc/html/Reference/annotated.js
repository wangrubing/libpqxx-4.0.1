var annotated =
[
    [ "pqxx", "a00176.html", "a00176" ],
    [ "std", null, [
      [ "numeric_limits", "a00065.html", "a00065" ],
      [ "char_traits", "a00015.html", null ],
      [ "char_traits< char >", "a00016.html", "a00016" ],
      [ "char_traits< unsigned char >", "a00017.html", "a00017" ],
      [ "back_insert_iterator< pqxx::tablewriter >", "a00005.html", "a00005" ]
    ] ]
];