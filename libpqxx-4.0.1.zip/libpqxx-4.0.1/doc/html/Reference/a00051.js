var a00051 =
[
    [ "invalid_cursor_state", "a00051.html#a39081c92939fa3cca69441719eae3415", null ],
    [ "invalid_cursor_state", "a00051.html#a98b63bef3455bdde8a791fbb49ca97f0", null ]
];